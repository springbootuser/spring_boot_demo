package com.capgemini.rest.child;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChildApp 
{
    public static void main( String[] args )
    {
        SpringApplication.run(ChildApp.class, args);
    }
}
