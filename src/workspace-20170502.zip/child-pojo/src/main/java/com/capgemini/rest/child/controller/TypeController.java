package com.capgemini.rest.child.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.rest.model.PojoModel;

@RestController
@RequestMapping(value = "/type")
public class TypeController {
	
	@RequestMapping(value = "/map")
	public Map<String, String> getMap() {
		Map<String, String> map = new HashMap<>();
		map.put("Key1", "Value1");
		map.put("Key2", "Value2");
		map.put("Key3", "Value3");
		return map;
	}
	
	@RequestMapping(value = "/pojo")
	@ResponseBody
	public PojoModel getPojo() {
		return new PojoModel("Name123", "Value246");
	}
}
