package com.capgemini.rest.scheduler.job;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.concurrent.FailureCallback;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.SuccessCallback;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.capgemini.rest.model.PojoModel;

public class DependentJobImpl implements Job {
	private static final Logger logger = LoggerFactory.getLogger(DependentJobImpl.class);
	
	private RestTemplate restTemplate = new RestTemplate();
	private AsyncRestTemplate nonBlockingRestTemplate = new AsyncRestTemplate();
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDetail jobDetail = context.getJobDetail();
		
		if (jobDetail instanceof DependentJobDetailImpl) {
			DependentJobDetailImpl job = (DependentJobDetailImpl)jobDetail;
			
			String group = context.getJobDetail().getKey().getGroup();
			String name = context.getJobDetail().getKey().getName();
			ExecutionMode mode = job.getExecutionMode();
			logger.info(">>>");
			logger.info(">> {}:{} starts with {} {}", group, name, mode, job.getActionUriList());
			
			for (URI path : job.getActionUriList()) {
				try {
					if (mode == ExecutionMode.SYNCHRONIZED) {
						Object jacksonObj = restTemplate.getForObject(path, Object.class);
						genericHandler(path, jacksonObj);
					} else if (mode == ExecutionMode.ASYNCHRONIZED) {
						ListenableFuture<ResponseEntity<Object>> future = nonBlockingRestTemplate.getForEntity(path, Object.class);
						future.addCallback(new SuccessCallback<ResponseEntity<Object>>() {
							@Override
							public void onSuccess(ResponseEntity<Object> result) {
								//HttpHeaders headers = result.getHeaders();
								//headers.keySet().forEach(key -> logger.info("header {key:{},value:{}}", key, headers.get(key)));
								
								Object jacksonObj = result.getBody();
								genericHandler(path, jacksonObj);
							}
						}, new FailureCallback() {
							@Override
							public void onFailure(Throwable ex) {
								byteArrayHandler(path, mode);
							}
						});
					}
				} catch (HttpMessageNotReadableException e) {
					byteArrayHandler(path, mode);
				} catch (RestClientException e) {
					e.printStackTrace();
				}
			}
			
//			try {
//				Thread.sleep(2000 + new Random().nextInt(5) * 2000);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
			
			logger.info(">> {}:{} ends", group, name);
		}
	}
	
	private void genericHandler(URI path, Object jacksonObj) {
		try {
			logger.info("Content from \"{}\": {}", path, jacksonObj);
			Object obj = new ObjectMapper().convertValue(jacksonObj, jacksonObj.getClass());
			
			if (obj instanceof Map) {
				Map<?, ?> map = (Map<?, ?>) obj;
				logger.info(">> Map content from [{}]: {}", path, map);
//				map.keySet().forEach(key -> {
//					logger.info("header {key={},value={}}", key, map.get(key));
//				});
			} else if (obj instanceof String) {
				String s = (String) obj;
				logger.info(">> String content from [{}]: {}", path, s);
			} else if (obj instanceof Integer) {
				Integer i = (Integer) obj;
				logger.info(">> Integer content from [{}]: {}", path, i);
			} else if (obj instanceof PojoModel) {
				PojoModel model = (PojoModel) obj;
				logger.info(">> POJO content from [{}]: {name={},value={}}", path, model.getName(), model.getValue());
			} else if (obj instanceof byte[]) {
				try {
					logger.info(">> byte[] String content from [{}]: {}", path, new String((byte[]) obj, "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			} else if (obj instanceof List) {
				List<?> list = (List<?>) obj;
				list.forEach(element -> {
					if (element instanceof byte[]) {
						byte[] b = (byte[]) element;
						try {
							logger.info(">> byte[] list content from [{}]: {}", path, new String(b, "UTF-8"));
						} catch (UnsupportedEncodingException e) {
							e.printStackTrace();
						}
					} else if (element instanceof String) {
						String s = (String) element;
						logger.info(">> String list content from [{}]: {}", path, s);
					} else {
						logger.info("Unknown list content from [{}]: {class={},toString={}}", path, element.getClass(), element);
					}
				});
			} else {
				logger.info(">> Unknown content from [{}]: {class={},toString={}}", path, obj.getClass(), obj);
			}
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
	}
	
	private void byteArrayHandler(URI path, ExecutionMode mode) {
		if (ExecutionMode.SYNCHRONIZED == mode) {
			byte[] b = restTemplate.getForObject(path, byte[].class);
			try {
				logger.info(">> byte[] string content from [{}]: {}", path, new String(b, "UTF-8"));
				//logger.info(">> byte[] decoded string content from [{}]: {}", path, new String(Base64.getDecoder().decode(new String(b, "UTF-8")), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (ExecutionMode.ASYNCHRONIZED == mode) {
			ListenableFuture<ResponseEntity<byte[]>> future = nonBlockingRestTemplate.getForEntity(path, byte[].class);
			future.addCallback(new SuccessCallback<ResponseEntity<byte[]>>() {
				@Override
				public void onSuccess(ResponseEntity<byte[]> result) {
					try {
						logger.info(">> byte[] string content from [{}]: {}", path, new String(result.getBody(), "UTF-8"));
						// logger.info(">> byte[] decoded string content from [{}]: {}", path, new String(Base64.getDecoder().decode(new String(result.getBody(), "UTF-8")), "UTF-8"));
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					}
				}
			}, new FailureCallback() {
				@Override
				public void onFailure(Throwable ex) {
					ex.printStackTrace();
				}
			});
		}
	}
}
