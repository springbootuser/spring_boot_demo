package com.capgemini.rest.scheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedulerApp 
{
    public static void main( String[] args )
    {
        SpringApplication.run(SchedulerApp.class, args);
    }
}
