import requests

result = requests.get('https://files.pythonhosted.org/packages/fb/ed/690b971a7b87c6babb15b4097e534f0cc2e6957feb2233e7d279283c61c8/requests3-0.0.0.tar.gz')
print(result.status_code)
print(result.content)